import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * مشروع استكشاف الواجهات الرسومية في جافا - GUIExploration.java
 * ===========================================================================
 * تطبيق عملي لمادة البرمجة كائنية التوجه (OOP / PBO-11)
 * يوضح هذا الكود كيفية بناء واجهة مستخدم متكاملة باستخدام مكتبة Swing
 * من خلال دمج العناصر الخمسة الأساسية للواجهات الرسومية:
 *
 *  [1] الحاوية الرئيسية (Top-Level Container):
 *      - JFrame: تمثل الإطار الخارجي والنافذة الأساسية للتطبيق.
 *
 *  [2] الحاويات الفرعية والوسيطة (Intermediate Containers):
 *      - JPanel و JScrollPane: لتجميع العناصر وتنظيمها وإضافة شريط التمرير.
 *
 *  [3] العناصر التفاعلية الأساسية (Atomic Components):
 *      - JLabel, JTextField, JComboBox, JRadioButton, JCheckBox, JTextArea, JButton.
 *
 *  [4] مديرو التخطيط (Layout Managers):
 *      - BorderLayout, FlowLayout, GridLayout: للتحكم في توزيع العناصر.
 *
 *  [5] معالجات الأحداث (Event Listeners):
 *      - ActionListener, KeyAdapter, MouseAdapter, WindowAdapter.
 * ===========================================================================
 */
public class GUIExploration extends JFrame {

    // تعريف الحقول والعناصر كخصائص عامة داخل الكلاس ليسهل الوصول إليها وتحديثها من داخل دوال الأحداث
    private JTextField nameField;
    private JTextField nimField;
    private JComboBox<String> classCombo;
    private JRadioButton maleRadio;
    private JRadioButton femaleRadio;
    private JCheckBox readingCheck;
    private JCheckBox sportsCheck;
    private JCheckBox musicCheck;
    private JTextArea notesArea;
    private JLabel statusLabel;
    private JLabel charLabel;

    /**
     * المشيّد (Constructor):
     * نقطه التهيئة الرئيسية للواجهة؛ يقوم بضبط أبعاد النافذة، توزيع اللوحات،
     * إضافة حقول الإدخال، وربط كل زر أو حقل بالحدث الخاص به.
     */
    public GUIExploration() {

        // ------------------------------------------------------------------
        // أولاً: تهيئة النافذة الرئيسية (JFrame - Top Level Container)
        // ------------------------------------------------------------------
        setTitle("GUI Exploration - Student Data Form"); // تعيين النص الظاهر في شريط عنوان النافذة
        setSize(560, 540);                               // تحديد العرض والارتفاع بالبكسل
        setLocationRelativeTo(null);                     // جعل النافذة تظهر في منتصف الشاشة تماماً
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);   // تعطيل الإغلاق المباشر لتفعيل رسالة التأكيد المخصصة

        // ------------------------------------------------------------------
        // ثانياً: اعتماد التخطيط الحدودي (BorderLayout) للنافذة الأم
        // ------------------------------------------------------------------
        setLayout(new BorderLayout(8, 8));

        // ------------------------------------------------------------------
        // ثالثاً: بناء شريط العنوان العلوي (JPanel + FlowLayout + JLabel)
        // ------------------------------------------------------------------
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("Student Data Form");
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 20));
        headerPanel.add(titleLabel);
        add(headerPanel, BorderLayout.NORTH);

        // ------------------------------------------------------------------
        // رابعاً: تصميم شبكة حقول الإدخال (GridLayout بواقع 5 صفوف وعمودين)
        // ------------------------------------------------------------------
        JPanel formPanel = new JPanel(new GridLayout(5, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));

        // الخانة 1: إدخال اسم الطالب
        formPanel.add(new JLabel("Name :"));
        nameField = new JTextField();
        formPanel.add(nameField);

        // الخانة 2: إدخال الرقم الجامعي (NIM)
        formPanel.add(new JLabel("NIM :"));
        nimField = new JTextField();
        formPanel.add(nimField);

        // الخانة 3: اختيار الشعبة الدراسية من القائمة المنسدلة
        formPanel.add(new JLabel("Class :"));
        classCombo = new JComboBox<>(new String[]{"5A", "5B", "5C", "5D"});
        formPanel.add(classCombo);

        // الخانة 4: تحديد الجنس باستخدام أزرار الاختيار الأحادي (Radio Buttons)
        // ربط الزرين بـ ButtonGroup يضمن اختيار قيمة واحدة فقط في نفس اللحظة
        formPanel.add(new JLabel("Gender :"));
        JPanel genderPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        maleRadio = new JRadioButton("Male", true);
        femaleRadio = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(maleRadio);
        genderGroup.add(femaleRadio);
        genderPanel.add(maleRadio);
        genderPanel.add(femaleRadio);
        formPanel.add(genderPanel);

        // الخانة 5: تحديد الهوايات (CheckBoxes) مع إمكانية اختيار أكثر من هواية معاً
        formPanel.add(new JLabel("Hobbies :"));
        JPanel hobbyPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        readingCheck = new JCheckBox("Reading");
        sportsCheck = new JCheckBox("Sports");
        musicCheck = new JCheckBox("Music");
        hobbyPanel.add(readingCheck);
        hobbyPanel.add(sportsCheck);
        hobbyPanel.add(musicCheck);
        formPanel.add(hobbyPanel);

        // ------------------------------------------------------------------
        // خامساً: منطقة الملاحظات الإضافية مدعومة بشريط تمرير (JScrollPane)
        // ------------------------------------------------------------------
        JPanel notesPanel = new JPanel(new BorderLayout(4, 4));
        notesPanel.setBorder(BorderFactory.createEmptyBorder(4, 12, 4, 12));
        notesPanel.add(new JLabel("Notes :"), BorderLayout.NORTH);
        notesArea = new JTextArea(5, 30);
        notesArea.setLineWrap(true);        // الانتقال التلقائي لسطر جديد عند امتلاء العرض
        notesArea.setWrapStyleWord(true);   // منع تقسيم الكلمة الواحدة بين سطرين
        JScrollPane scrollPane = new JScrollPane(notesArea); // تغليف مربع النص بشريط تمرير
        notesPanel.add(scrollPane, BorderLayout.CENTER);

        // دمج لوحة البيانات ولوحة الملاحظات في حاوية وسطى واحدة
        JPanel centerPanel = new JPanel(new BorderLayout(4, 4));
        centerPanel.add(formPanel, BorderLayout.NORTH);
        centerPanel.add(notesPanel, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        // ------------------------------------------------------------------
        // سادساً: المنطقة السفلية (أزرار التحكم + شريط الحالة والعداد)
        // ------------------------------------------------------------------
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        JButton submitButton = new JButton("Submit");
        JButton clearButton = new JButton("Clear");
        JButton exitButton = new JButton("Exit");
        buttonPanel.add(submitButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(exitButton);

        // شريط معلومات سفلي يعرض حالة النظام على اليسار وعدد أحرف الاسم على اليمين
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEmptyBorder(2, 12, 6, 12));
        statusLabel = new JLabel("Ready.");
        charLabel = new JLabel("Name characters: 0");
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(charLabel, BorderLayout.EAST);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(buttonPanel, BorderLayout.CENTER);
        southPanel.add(statusPanel, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        // ==================================================================
        // سابعاً: برمجة التفاعل والاستجابة للأحداث (Event Handling)
        // ==================================================================

        // 1. حدث النقر على زر الإرسال (Submit): يقرأ المدخلات ويعرض ملخصاً في نافذة منبثقة
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String gender = maleRadio.isSelected() ? "Male" : "Female";

                // بناء نص الهوايات المختارة، أو وضع شرطة (-) في حال عدم اختيار أي هواية
                StringBuilder hobbies = new StringBuilder();
                if (readingCheck.isSelected()) hobbies.append("Reading ");
                if (sportsCheck.isSelected()) hobbies.append("Sports ");
                if (musicCheck.isSelected()) hobbies.append("Music ");
                String hobbyText = hobbies.length() == 0 ? "-" : hobbies.toString().trim();

                // تنسيق كافة المعلومات المدخلة لعرضها بشكل منظم
                String message = "Name  : " + nameField.getText()
                        + "\nNIM    : " + nimField.getText()
                        + "\nClass  : " + classCombo.getSelectedItem()
                        + "\nGender : " + gender
                        + "\nHobbies: " + hobbyText
                        + "\nNotes  : " + notesArea.getText();

                JOptionPane.showMessageDialog(GUIExploration.this, message,
                        "Submitted Data", JOptionPane.INFORMATION_MESSAGE);
                statusLabel.setText("Data submitted for: " + nameField.getText());
            }
        });

        // 2. حدث النقر على زر المسح (Clear): يعيد ضبط النموذج بالكامل إلى حالته الأولية
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nameField.setText("");
                nimField.setText("");
                classCombo.setSelectedIndex(0);
                maleRadio.setSelected(true);
                readingCheck.setSelected(false);
                sportsCheck.setSelected(false);
                musicCheck.setSelected(false);
                notesArea.setText("");
                charLabel.setText("Name characters: 0");
                statusLabel.setText("Form cleared.");
            }
        });

        // 3. حدث النقر على زر الخروج (Exit): يستدعي دالة التحقق قبل إغلاق التطبيق
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                closeWindow();
            }
        });

        // 4. حدث الكتابة في حقل الاسم (KeyAdapter): يحسب طول النص فورياً مع كل ضغطة زر
        nameField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                charLabel.setText("Name characters: " + nameField.getText().length());
            }
        });

        // 5. أحداث حركة الماوس فوق زر الإرسال (MouseAdapter): تغيير لون الزر وإظهار تلميح إرشادي
        submitButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                submitButton.setBackground(new Color(180, 220, 180));
                statusLabel.setText("Click Submit to send the form.");
            }

            @Override
            public void mouseExited(MouseEvent e) {
                submitButton.setBackground(null);
                statusLabel.setText("Ready.");
            }
        });

        // 6. حدث الضغط على أيقونة الإغلاق (X) في إطار النافذة (WindowAdapter)
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                closeWindow();
            }
        });
    }

    /**
     * دالة مساعدة لتأكيد الخروج:
     * تمنع إغلاق البرنامج بالخطأ عبر إظهار رسالة تأكيد (نعم/لا) للمستخدم.
     */
    private void closeWindow() {
        int answer = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to exit?",
                "Exit Confirmation", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }

    /**
     * نقطة انطلاق البرنامج (Main Method):
     * تشغّل الواجهة الرسومية داخل مسار معالجة الأحداث (EDT) لضمان استقرار العرض.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUIExploration().setVisible(true);
            }
        });
    }
}